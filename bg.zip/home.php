<!-- TICTACTOE.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="home.css">
    <title>Tic Tac Toe Game</title>
</head>
<body>
    <div class="container">
        <h1>TIC-TAC-TWO</h1>
        <p>CREATED BY: 
            <br>
            AVILA, SORIA, ILETO, GAMAZON, FRANSICO</p>
        <a href="TIKTACTOE.php" class="button-link">Play Now</a>
    </div>
</body>
</html>
